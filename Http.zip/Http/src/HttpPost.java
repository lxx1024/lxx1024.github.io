import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;

import net.sf.json.JSONObject;

public class HttpPost {
	public static void main(String[] args) {
		try {
			// 将用户名和密码放入json对象中
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("username", "Aiden");
			jsonObject.put("passwor", "Aiden");

			// 新建HttpClient对象，用于访问jsp
			HttpClient httpClient = new HttpClient();
			PostMethod postMethod = new PostMethod("http://localhost:8080/Http/LoginPost.jsp");

			// 让post请求携带json数据
			String string = jsonObject.toString();
			RequestEntity requestEntity = new StringRequestEntity(string, "application/json", "UTF-8");
			postMethod.setRequestEntity(requestEntity);

			// 发送post请求
			httpClient.executeMethod(postMethod);
			// 得到响应内容
			String result = new String(postMethod.getResponseBody());
			System.out.println(result.trim());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
