import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;

public class HttpGet {

	public static void main(String[] args) {
		HttpClient httpClient = new HttpClient();
		// 将账号密码放入路径中
		GetMethod getMethod = new GetMethod("http://localhost:8080/Http/LoginGet.jsp?username=Aiden&password=Aiden");
		try {
			httpClient.executeMethod(getMethod);
			String result = new String(getMethod.getResponseBody());
			System.out.println(result.trim());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
